// accounts.js
module.exports = [
    { email: "user1@example.com", token: "token1" },
    { email: "user2@example.com", token: "token2" },
    // Add more accounts as needed
];